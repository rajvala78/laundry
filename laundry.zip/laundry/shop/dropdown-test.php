<?php  include "../connect.php"; ?>


<?php
$state = "select * from cities";
$state_qry = mysqli_query($conn, $state);
?>
<div class="form-group row">
    <label for="inputName2" class="col-sm-2 col-form-label">City</label>
    <div class="form-group col-sm-10">
        <select class="form-control">


            <?php
               $records = mysqli_query($conn,"select * from cities");       
            while($data = mysqli_fetch_array($records)){
                    echo "<option value='".$data['city_name']."'>".$data['city_name']."</option>";
                }
            ?>



<!--<!--            --><?php
//            $records = mysqli_query($conn,"select * from cities");
//           while($data = mysqli_fetch_array($records)){
//                echo "<option value='".$data['city_name']."'>".$data['city_name']."</option>";
//            }
//            ?><!---->-->

        </select>
    </div>
</div>
