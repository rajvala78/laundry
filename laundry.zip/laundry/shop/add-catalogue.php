<?php
include "../connect.php";
session_start();
$email = $_SESSION['email'];
require "include/function.php";

$GetShopData = GetShopData($conn, $email);
$shop_id = $GetShopData['shop_id'];
$username = $GetShopData['username'];
$name = $GetShopData['name'];


// echo $shop_id;

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>AdminLTE 3 | Dashboard 3</title>
    <?php include "include/head-design.php" ?>

</head>

<body class="hold-transition sidebar-mini">
<div class="wrapper">

    <!-- Main Sidebar Container -->
    <?php include "include/sidebar.php"; ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Add Customer</h1>
                    </div>
                    <!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item active">Add Customer</li>
                        </ol>
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>


        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <!-- /.col -->
                    <div class="col-md-12">
                        <div class="card">
                            <!-- /.card-header -->
                            <div class="card-body">
                                <div class="tab-content">
                                    <form class="form-horizontal" method="post" action="">
                                        <div class="form-group row">
                                            <label for="dc_type" class="col-sm-2
                                            col-form-label">Dry Clean Type</label>
                                            <div class="col-sm-10">
                                                <input type="text" value="" id="dc_type"
                                                       class="form-control" name="dc_type"
                                                       placeholder="Dry Clean
                                                       Type">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="offset-sm-2 col-sm-10">
                                                <button type="submit" name="submit" class="btn
                                                btn-danger">Submit</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                <!-- /.tab-content -->
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                    <!-- /.col -->
                    <div class="col-md-12">
                        <div class="card">
                            <!-- /.card-header -->
                            <div class="card-body">
                                <table id="example2" class="table table-bordered table-hover">
                                    <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>DC Type</th>
                                        <th>Option</th>
                                    </thead>
                                    <tbody>
                                    <?php
                                    // echo $shop_id;
                                    $stmt = $conn -> prepare("select * from catalogue where shop_id = ?");
                                    $stmt -> bind_param("i", $shop_id);
                                    $stmt -> execute();
                                    $result = $stmt -> get_result();
                                    while($data = $result -> fetch_assoc()){
                                        ?>
                                        <tr>
                                            <td><?php echo $data['id']; ?></td>
                                            <td><?php echo $data['dc_type']; ?></td>

                                            <td><a href="/laundry/shop/edit-catalogue.php?id=<?php echo
                                                $data['id'];
                                                ?>"
                                                   class="button">Edit</a>  |  <a
                                                    href="/laundry/shop/delete-catalogue.php?id=<?php echo
                                                    $data['id'];
                                                    ?>"
                                                    class="button">Delete</a>
                                            </td>
                                        </tr>
                                    <?php
                                    }

                                    ?>
                                    </tfoot>
                                </table>
                                <!-- /.tab-content -->
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </section>
    </div>
    <!-- /.content-wrapper -->

    <?php
    if(isset($_POST['submit'])){

//        $shop_id = $_POST['shop_id'];
        $dc_type = $_POST['dc_type'];
        $stmt = $conn->prepare("insert into catalogue( id, shop_id, username, dc_type) VALUES(NULL,
?,?,
?)");
        $stmt->bind_param("iss", $shop_id, $username, $dc_type);
        $stmt->execute();
        $stmt->close();
        $conn->close();
    }
    ?>
    <!-- Main Footer -->
    <?php include "include/footer.php"; ?>
</div>
<!-- ./wrapper -->
<?php include "include/script.php"; ?>
</body>
</html>
