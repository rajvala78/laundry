<?php
ob_start();
include "../connect.php";
session_start();
$email = $_SESSION['email'];

$stmt = $conn->prepare("select * from shop where email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows == 1) {
    while ($data = $result->fetch_assoc()) {
        $username = $data['username'];
        $email = $data['email'];
        $shop_name = $data['shop_name'];
        $name = $data['name'];
        $mobile = $data['mobile'];
        $address = $data['address'];
        $city = $data['city_id'];
        $state = $data['state_id'];
        $shop_photo = $data['shop_photo'];
    }
}


?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>AdminLTE 3 | Dashboard 3</title>
    <?php include "include/head-design.php" ?>

</head>
<!--
`body` tag options:

  Apply one or more of the following classes to to the body tag
  to get the desired effect

  * sidebar-collapse
  * sidebar-mini
-->

<body class="hold-transition sidebar-mini">
    <div class="wrapper">

        <!-- Main Sidebar Container -->
        <?php include "include/sidebar.php"; ?>
        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0">Edit Profile</h1>
                        </div>
                        <!-- /.col -->
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="#">Home</a></li>
                                <li class="breadcrumb-item active">Edit Profile</li>
                            </ol>
                        </div>
                        <!-- /.col -->
                    </div>
                    <!-- /.row -->
                </div>
                <!-- /.container-fluid -->
            </div>


            <section class="content">
                <div class="container-fluid">
                    <div class="row">
                        <!-- /.col -->
                        <div class="col-md-12">
                            <div class="card">
                                <!-- /.card-header -->
                                <div class="card-body">
                                    <div class="card-body box-profile">
                                        <div class="text-center">
                                            <?php if(isset($shop_photo)) {


                                                echo '<img class="profile-user-img img-fluid img-circle"
                                                 src = "'.$shop_photo.'" alt = "'.$shop_name.'" >';

                                                }
                                            else{

                                                echo '<img class="profile-user-img img-fluid img-circle" src="dist/img/user4-128x128.jpg" alt="User profile picture">';
                                            }
                                            ?>

                                        </div>

                                        <h3 class="profile-username text-center">Raj Vala</h3>


                                    </div>
                                    <!-- /.card-body -->

                                    <div class="tab-content">
                                        <form class="form-horizontal" method="post" action="" enctype="multipart/form-data">
                                            <div class="form-group row">
                                                 <label for="customFile">Upload Profile</label>

                                                <div class="custom-file">
                                                    <input type="file" class="custom-file-input" name="shop_photo"
                                                           id="customFile">
                                                    <label class="custom-file-label" for="customFile">Choose file</label>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <label for="inputName" name="shop_name" class="col-sm-2
                                            col-form-label">Shop
                                                    Name</label>

                                                <div class="col-sm-10">
                                                    <input type="text" name="shop_name" class="form-control"
                                                        id="inputName" value="<?php if ($shop_name) {
                                                            echo $shop_name;
                                                        }
                                                        ?>" placeholder="Shop Name">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="inputEmail" class="col-sm-2 col-form-label">Email</label>

                                                <div class="col-sm-10">
                                                    <input type="email" value="<?php echo $email ?>"
                                                        class="form-control" id="inputEmail" name="email"
                                                        placeholder="Email">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="inputName2" class="col-sm-2 col-form-label">Name</label>

                                                <div class="col-sm-10">
                                                    <input type="text" class="form-control" name="name" value="<?php if ($name) {
                                                        echo $name;
                                                    }
                                                    ?>" id="inputName2" placeholder="Name">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="inputName2" class="col-sm-2 col-form-label">Mobile
                                                    No</label>

                                                <div class="col-sm-10">
                                                    <input type="number" name="mobile" class="form-control" id="contact"
                                                        value="<?php if ($mobile) {
                                                            echo $mobile;
                                                        }
                                                        ?>" placeholder="Mobile No">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="inputExperience" class="col-sm-2 col-form-label">Shop
                                                    Address</label>

                                                <div class="col-sm-10">
                                                    <textarea class="form-control" name="address" id="inputExperience"
                                                        placeholder="Address"><?php if ($address) {
                                                            echo $address;
                                                        }
                                                        ?></textarea>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <label for="inputName2" class="col-sm-2 col-form-label">Select
                                                    State</label>

                                                <div class="col-sm-10">
                                                    <select name="state" class="state custom-select form-control-border"
                                                        id="exampleSelectBorder">

                                                        <?php

                                                        $stmt = $conn->prepare("select * from cities GROUP by city_state ASC");
                                                        $stmt->execute();
                                                        $result = $stmt->get_result();


                                                        while ($data = $result->fetch_assoc()) {

                                                            if ($data['city_id'] == $state) {

                                                                echo '<option selected="selected" value="' . $data['city_id'] . '">'
                                                                    . $data['city_state']
                                                                    . '</option>';

                                                            } else {

                                                                echo '<option value="' . $data['city_id'] . '">'
                                                                    . $data['city_state']
                                                                    . '</option>';

                                                            }




                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>


                                            <div class="form-group row">
                                                <label for="inputName2" class="col-sm-2 col-form-label">Select
                                                    City</label>
                                                <div class="col-sm-10">

                                                    <select name="city" class="city custom-select form-control-border"
                                                        id="exampleSelectBorder">


                                                        <?php

                                                        if (isset($city)) {


                                                            $stmt = $conn->prepare("select * from cities where city_id = ?");
                                                            $stmt->bind_param("s", $city);
                                                            $stmt->execute();
                                                            $result = $stmt->get_result();


                                                            while ($data = $result->fetch_assoc()) {

                                                                if ($data['city_id'] == $city) {

                                                                    echo '<option selected="selected" value="' . $data['city_id']
                                                                        . '">' .
                                                                        $data['city_name']
                                                                        . '</option>';
                                                                }

                                                            }
                                                        }
                                                        ?>

                                                    </select>
                                                </div>
                                            </div>




                                            <div class="form-group row">
                                                <div class="offset-sm-2 col-sm-10">
                                                    <button type="submit" name="submit" class="btn
                                                btn-danger">Submit</button>
                                                </div>
                                            </div>
                                        </form>

                                        <!-- /.tab-pane -->
                                        <?php
                                        if (isset($_POST['submit'])) {

                                            $shop_name = $_POST['shop_name'];
                                            $email = $_POST['email'];
                                            $name = $_POST['name'];
                                            $mobile = $_POST['mobile'];
                                            $address = $_POST['address'];
                                            $city = $_POST['city'];
                                            $state = $_POST['state'];



                                            $target_dir = "shop-photos/";
                                            $filename   = "shop-photo-" . date("d-m-y") . "-" . time(); //
                                            // 5dab1961e93a7-1571494241
                                            $imageFileType  = pathinfo( $_FILES["shop_photo"]["name"],
                                                PATHINFO_EXTENSION ); // jpg
                                            $basename   = $filename . "." . $imageFileType; // 5dab1961e93a7_1571494241.jpg
                                            $source       = $_FILES["shop_photo"]["tmp_name"];
                                            $target_file = $target_dir . $basename;
                                            $uploadOk = 1;

                                        // Allow certain file formats
                                        if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
                                            && $imageFileType != "gif" && $source != NULL ) {
                                            echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
                                            $uploadOk = 0;
                                        }


                                        // Check if $uploadOk is set to 0 by an error
                                        if ($uploadOk == 0 && $source != NULL) {
                                            echo "Sorry, your file was not uploaded.";

// if everything is ok, try to upload file
                                        } else {

                                            if($source != NULL && $uploadOk = 1){

                                                if (move_uploaded_file($source, $target_file)) {
                                                   // echo "The file " . htmlspecialchars($target_file) . " has been
                                                   // uploaded.";

                                                    $stmt = $conn->prepare("update shop set shop_name = ? , email = ? , name=?
                                            , mobile = ? , address = ? , city_id = ? , state_id = ?, shop_photo = ?
                                            where username =
                                            ? ");
                                                    $stmt->bind_param(
                                                        "sssisiiss",
                                                        $shop_name,
                                                        $email,
                                                        $name,
                                                        $mobile,
                                                        $address,
                                                        $city,
                                                        $state,
                                                        $target_file,
                                                        $username
                                                    );

                                                    $stmt->execute();
                                                    header("Location: /laundry/shop/edit-profile.php");

                                                    ob_flush();




                                                } else {
                                                    echo "Sorry, there was an error uploading your file.";
                                                }

                                            }
                                            else{

                                                $stmt = $conn->prepare("update shop set shop_name = ? , email = ? , name=?
                                            , mobile = ? , address = ? , city_id = ? , state_id = ? where username =
                                            ? ");
                                                $stmt->bind_param(
                                                    "sssisiis",
                                                    $shop_name,
                                                    $email,
                                                    $name,
                                                    $mobile,
                                                    $address,
                                                    $city,
                                                    $state,
                                                    $username
                                                );

                                                $stmt->execute();
                                                header("Location: /laundry/shop/edit-profile.php");
                                                ob_flush();


                                            }
                                            }
                                        }
                                        ?>

                                        <!-- /.tab-pane -->


                                        <!-- /.tab-pane -->
                                    </div>
                                    <!-- /.tab-content -->
                                </div>
                                <!-- /.card-body -->
                            </div>
                            <!-- /.card -->
                        </div>
                        <!-- /.col -->
                    </div>
                    <!-- /.row -->
                </div>
                <!-- /.container-fluid -->
            </section>
        </div>
        <!-- /.content-wrapper -->

        <!-- Control Sidebar -->

        <!-- /.control-sidebar -->

        <!-- Main Footer -->
        <?php include "include/footer.php"; ?>
    </div>
    <!-- ./wrapper -->
    <!-- bs-custom-file-input -->
    <script src="plugins/bs-custom-file-input/bs-custom-file-input.min.js"></script>
    <?php include "include/script.php"; ?>
</body>

</html>



<script>
    $(document).ready(function () {
        $(".state").change(function () // as state change, ajax will be called along with passing state value
        {
            //alert("working");
            var id = $(this).val();// it will contain the selected state value
            var dataString = 'state_id=' + id; // it will bind state value as post data to ajax
            $.ajax
                ({
                    type: "POST",
                    url: "ajax_city_get.php", // this file will find list of all city names from state name
                    data: dataString, // it will pass parameters (state name)
                    cache: false,
                    success: function (html) {

                        $(".city").html(html); // this will set list of cities in city list
                    }

                });
        });
    });</script>

<script>
    $(function () {
        bsCustomFileInput.init();
    });
</script>