<?php

function GetShopData($conn, $email){
    $stmt = $conn->prepare("select * from shop where email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows == 1) {
        while ($data = $result->fetch_assoc()) {
            $shop_id = $data['id'];
            $username = $data['username'];
            $email = $data['email'];
            $shop_name = $data['shop_name'];
            $name = $data['name'];
            $mobile = $data['mobile'];
            $address = $data['address'];
//        $city = $data['city'];
            //      $state = $data['state'];
        }
    }
    return array("shop_id" =>$shop_id, "username" => $username, "email"=>$email, "shop_name" => $shop_name,
        "name" => $name, "mobile" =>  $mobile, "address" => $address);


}



function GetCatalogueData($conn, $shop_id){
    $stmt = $conn->prepare("select * from catalogue where shop_id = ?");
    $stmt->bind_param("i", $shop_id);
    $stmt->execute();
    $result = $stmt->get_result();
                while ($data = $result->fetch_assoc()) {
                    $id = $data['id'];
            $shop_id = $data['shop_id'];
            $username = $data['username'];
            $dc_type = $data['dc_type'];
        }

    return array("id" =>$id,"shop_id" =>$shop_id, "username" => $username, "dc_type" => $dc_type);
}
