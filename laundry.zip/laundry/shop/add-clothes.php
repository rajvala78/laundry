<?php
include "../connect.php";
session_start();
$email = $_SESSION['email'];
require "include/function.php";

$GetShopData = GetShopData($conn, $email);
$shop_id = $GetShopData['shop_id'];
//$cat_id = $_GET['id'];
$shop_username =  $GetShopData['username'];
$name = $GetShopData['name'];


?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>AdminLTE 3 | Dashboard 3</title>
    <?php include "include/head-design.php" ?>

</head>

<body class="hold-transition sidebar-mini">
<div class="wrapper">

    <!-- Main Sidebar Container -->
    <?php include "include/sidebar.php"; ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Add Customer</h1>
                    </div>
                    <!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item active">Add Customer</li>
                        </ol>
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>


        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-3">
                        <!-- /.card -->
                    </div>
                    <!-- /.col -->
                    <div class="col-md-12">
                        <div class="card">
                            <!-- /.card-header -->
                            <div class="card-body">
                                <div class="tab-content">
                                    <form class="form-horizontal" method="post" action="">
                                        <div class="form-group row">
                                            <label for="dc_type" class="col-sm-2
                                            col-form-label">Dry Clean Type</label>

                                            <div class="col-sm-10">
                                                <select name="dc_type" class="state custom-select
                                                    form-control-border"
                                                        id="dc_type">

                                                    <?php

                                                    $stmt = $conn->prepare("select * from catalogue where shop_id = ?");
                                                    $stmt->bind_param("i", $shop_id);
                                                    $stmt->execute();
                                                    $result = $stmt->get_result();


                                                    while ($data = $result->fetch_assoc()) {


                                                        echo '<option value="' . $data['id'] . '">'
                                                            . $data['dc_type']
                                                            . '</option>';
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label for="clothes" class="col-sm-2
                                            col-form-label">Clothes Type</label>

                                            <div class="col-sm-10">
                                                <input type="text" value="" id="clothes" class="form-control"
                                                       name="clothes" placeholder="clothes Type">
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label for="quantity" class="col-sm-2
                                            col-form-label">Quantity</label>

                                            <div class="col-sm-10">
                                                <input type="number" value="" id="quantity" class="form-control"
                                                       name="quantity" placeholder=" Quantity of clothes">
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label for="price" class="col-sm-2
                                            col-form-label">price</label>

                                            <div class="col-sm-10">
                                                <input type="number" value="" id="price" class="form-control"
                                                       name="price" placeholder="Price of clothes">
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <div class="offset-sm-2 col-sm-10">
                                                <button type="submit" name="submit" class="btn
                                                btn-danger">Submit
                                                </button>
                                            </div>
                                        </div>
                                    </form>
                                    <!-- /.tab-pane -->
                                    <?php
                                    if (isset($_POST['submit'])) {


                                        $dc_type = $_POST['dc_type'];


                                        $clothes = $_POST['clothes'];
                                        $quantity = $_POST['quantity'];
                                        $price = $_POST['price'];


                                        $stmt = $conn->prepare("insert into clothes ( id, shop_id, cat_id, username, clothes, quantity, price) VALUES (Null,?,?,?,?,?,?)");
                                        $stmt->bind_param("iissii", $shop_id, $dc_type, $shop_username, $clothes,
                                            $quantity, $price );
                                        $stmt->execute();
                                        $stmt->close();
                                        $conn->close();

                                    }
                                    ?>
                                </div>
                                <!-- /.tab-content -->
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </section>
    </div>
    <!-- /.content-wrapper -->


    <!-- Main Footer -->
    <?php include "include/footer.php"; ?>
</div>
<!-- ./wrapper -->
<?php include "include/script.php"; ?>
</body>

</html>
