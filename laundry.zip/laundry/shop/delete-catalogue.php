<?php
include "../connect.php";
session_start();
$email = $_SESSION['email'];
require "include/function.php";

$GetShopData = GetShopData($conn, $email);
$shop_id = $GetShopData['shop_id'];
$cat_id = $_GET['id'];
// echo $customer_id;


$stmt = $conn->prepare("Delete from catalogue WHERE id = ? and shop_id = ?");
$stmt->bind_param("ii", $cat_id, $shop_id);
$stmt->execute();
header("Location: /laundry/shop/add-catalogue.php");

?>