<?php
ob_start();
include "../connect.php";
session_start();
$email = $_SESSION['email'];
require "include/function.php";

$GetShopData = GetShopData($conn, $email);
$shop_id = $GetShopData['shop_id'];
$username = ['username'];
$cat_id = $_GET['id'];



// echo $cat_id;

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>AdminLTE 3 | Dashboard 3</title>
    <?php include "include/head-design.php" ?>

</head>


<body class="hold-transition sidebar-mini">
    <div class="wrapper">

        <!-- Main Sidebar Container -->
        <?php include "include/sidebar.php"; ?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0">Add Customer</h1>
                        </div>
                        <!-- /.col -->
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="#">Home</a></li>
                                <li class="breadcrumb-item active">Edit Catalogue</li>
                            </ol>
                        </div>
                        <!-- /.col -->
                    </div>
                    <!-- /.row -->
                </div>
                <!-- /.container-fluid -->
            </div>


            <section class="content">
                <div class="container-fluid">
                    <div class="row">
                        <!-- /.col -->
                        <div class="col-md-12">
                            <div class="card">
                                <!-- /.card-header -->
                                <div class="card-body">
                                    <div class="tab-content">
                                        <form class="form-horizontal" method="post" action="">
                                            <div class="form-group row">
                                                <label for="dc_type" class="col-sm-2
                                            col-form-label">Dry Clean Type</label>
                                                <div class="col-sm-10">
                                                    <input type="text" value="" id="dc_type" class="form-control"
                                                        name="dc_type" placeholder="Dry Clean
                                                       Type">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <div class="offset-sm-2 col-sm-10">
                                                    <button type="submit" name="submit" class="btn
                                                btn-danger">Submit</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    <!-- /.tab-content -->
                                </div>
                                <!-- /.card-body -->
                            </div>
                            <!-- /.card -->
                        </div>
                        <!-- /.col -->

                    </div>
                    <!-- /.row -->
                </div>
                <!-- /.container-fluid -->
            </section>
        </div>
        <!-- /.content-wrapper -->

        <?php
        if (isset($_POST['submit'])) {

            // $cat_id = $_POST['id'];
            $dc_type = $_POST['dc_type'];
            $stmt = $conn->prepare("update catalogue set dc_type = ? where id =?");
            $stmt->bind_param("si", $dc_type, $cat_id);
            $stmt->execute();
            $stmt->close();
            $conn->close();
            header("Location: /laundry/shop/add-catalogue.php");
            ob_flush();
        }
        ?>
        <!-- Main Footer -->
        <?php include "include/footer.php"; ?>
    </div>
    <!-- ./wrapper -->
    <?php include "include/script.php"; ?>
</body>

</html>