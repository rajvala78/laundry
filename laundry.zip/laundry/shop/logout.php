<?php

session_start();

session_destroy();
header("Location: /laundry/shop/index.php");
session_regenerate_id();



?>