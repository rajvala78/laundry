<?php
include "../connect.php";
session_start();
$email = $_SESSION['email'];
require "include/function.php";

$GetShopData = GetShopData($conn, $email);
$shop_id = $GetShopData['shop_id'];
$customer_id = $_GET['id'];


$stmt = $conn->prepare("select * from customer where id = ? && shop_id = ?");
$stmt->bind_param("ii", $customer_id, $shop_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows == 1) {
    while ($data = $result->fetch_assoc()) {
        $cust_username = $data['username'];
        $email = $data['email'];
        $name = $data['name'];
        $mobile = $data['mobile'];
        $address = $data['address'];
        $city = $data['city_id'];
        $state = $data['state_id'];
    }
}

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>AdminLTE 3 | Dashboard 3</title>
    <?php include "include/head-design.php" ?>

</head>
<!--
`body` tag options:

  Apply one or more of the following classes to to the body tag
  to get the desired effect

  * sidebar-collapse
  * sidebar-mini
-->
<body class="hold-transition sidebar-mini">
<div class="wrapper">

    <!-- Main Sidebar Container -->
    <?php include "include/sidebar.php"; ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Edit Customer</h1>
                    </div>
                    <!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item active">Edit Customer</li>
                        </ol>
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>


        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-3">

                        <!-- Profile Image -->

                        <!-- /.card -->

                        <!-- About Me Box -->

                        <!-- /.card -->
                    </div>
                    <!-- /.col -->
                    <div class="col-md-12">
                        <div class="card">
                            <!-- /.card-header -->
                            <div class="card-body">
                                <div class="tab-content">
                                    <form class="form-horizontal" method="post" action="">
                                        <div class="form-group row">
                                            <label for="inputusername" class="col-sm-2
                                            col-form-label">Customer Username</label>

                                            <div class="col-sm-10">
                                                <input type="text" value="<?php if(isset($cust_username)){ echo
                                                $cust_username; } ?>"
                                                       id="inputusername"
                                                       class="form-control" name="username"
                                                       placeholder="Username">
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label for="inputEmail" class="col-sm-2
                                            col-form-label">Customer Email</label>

                                            <div class="col-sm-10">
                                                <input type="email" value="<?php if(isset($email)){ echo
                                                $email; } ?>"
                                                       class="form-control" id="inputEmail" name="email"
                                                       placeholder="Email">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="inputName2" class="col-sm-2 col-form-label">Customer
                                                Name</label>

                                            <div class="col-sm-10">
                                                <input type="text" class="form-control" name="name" value="<?php if(isset($name)){ echo
                                                $name; } ?>" id="inputName2"
                                                       placeholder="Name">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="inputName2" class="col-sm-2 col-form-label">Customer Mobile
                                                No</label>

                                            <div class="col-sm-10">
                                                <input type="number"  name="mobile" class="form-control"
                                                       id="contact" value="<?php if(isset($mobile)){ echo
                                                $mobile; } ?>"
                                                       placeholder="Mobile No">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="inputExperience" class="col-sm-2 col-form-label">Customer
                                                Address</label>

                                            <div class="col-sm-10">
                                                <textarea class="form-control" name="address" id="inputExperience"
                                                          placeholder="Address"><?php if(isset($address)){ echo
                                                    $address; } ?></textarea>
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label for="inputName2" class="col-sm-2 col-form-label">Select State</label>

                                            <div class="col-sm-10">
                                                <select name="state" class="state custom-select form-control-border"
                                                        id="exampleSelectBorder">

                                                    <?php

                                                    $stmt = $conn -> prepare("select * from cities GROUP by city_state ASC");
                                                    $stmt -> execute();
                                                    $result = $stmt -> get_result();


                                                    while($data = $result -> fetch_assoc()){

                                                        if($data['city_id'] == $state){

                                                            echo '<option selected="selected" value="'.$data['city_id'].'">'
                                                                .$data['city_state']
                                                                .'</option>';

                                                        }else{

                                                            echo '<option value="'.$data['city_id'].'">'
                                                                .$data['city_state']
                                                                .'</option>';

                                                        }




                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>


                                        <div class="form-group row">
                                            <label for="inputName2" class="col-sm-2 col-form-label">Select City</label>
                                            <div class="col-sm-10">

                                                <select  name="city" class="city custom-select form-control-border"
                                                         id="exampleSelectBorder">


                                                    <?php

                                                    if(isset($city)) {


                                                        $stmt = $conn->prepare("select * from cities where city_id = ?");
                                                        $stmt->bind_param("s", $city);
                                                        $stmt->execute();
                                                        $result = $stmt->get_result();


                                                        while ($data = $result->fetch_assoc()) {

                                                            if ($data['city_id'] == $city) {

                                                                echo '<option selected="selected" value="'.$data['city_id']
                                                                    .'">'.
                                                                    $data['city_name']
                                                                    .'</option>';
                                                            }

                                                        }
                                                    }
                                                    ?>

                                                </select>
                                            </div>
                                        </div>




                                        <div class="form-group row">
                                            <div class="offset-sm-2 col-sm-10">
                                                <button type="submit" name="submit" class="btn
                                                btn-danger">Submit</button>
                                            </div>
                                        </div>
                                    </form>


                                    <!-- /.tab-pane -->


                                    <!-- /.tab-pane -->
                                </div>
                                <!-- /.tab-content -->
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </section>
    </div>
    <!-- /.content-wrapper -->

    <?php
    if(isset($_POST['submit'])){

//        $shop_id = $_POST['shop_id'];
        $email = $_POST['email'];
        $name = $_POST['name'];
        $mobile = $_POST['mobile'];
        $address = $_POST['address'];
        $state_id = $_POST['state'];
        $city_id = $_POST['city'];
        $password = "Test@123";
        $password = md5($password);


        $stmt = $conn->prepare("update customer set email = ? , name=?
                                            , mobile = ? , address = ? , city_id = ? , state_id = ? where id =
                                            ? ");
        $stmt->bind_param("ssssssi", $email, $name, $mobile,
            $address, $city, $state, $username);


        $stmt->execute();
        $stmt->close();
        $conn->close();

    }

    ?>
    <!-- /.control-sidebar -->

    <!-- Main Footer -->
    <?php include "include/footer.php"; ?>
</div>
<!-- ./wrapper -->

<?php include "include/script.php"; ?>
</body>
</html>
<script>
    $(document).ready(function()
    {
        $(".state").change(function() // as state change, ajax will be called along with passing state value
        {
            //alert("working");
            var id=$(this).val();// it will contain the selected state value
            var dataString = 'state_id='+ id; // it will bind state value as post data to ajax
            $.ajax
            ({
                type: "POST",
                url: "ajax_city_get.php", // this file will find list of all city names from state name
                data: dataString, // it will pass parameters (state name)
                cache: false,
                success: function(html)
                {

                    $(".city").html(html); // this will set list of cities in city list
                }

            });
        });
    });</script>