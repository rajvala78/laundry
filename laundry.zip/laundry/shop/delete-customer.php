<?php
include "../connect.php";
session_start();
$email = $_SESSION['email'];
require "include/function.php";

$GetShopData = GetShopData($conn, $email);
$shop_id = $GetShopData['shop_id'];
$customer_id = $_GET['id'];
echo $customer_id;

$stmt = $conn->prepare("Delete from customer WHERE id = ? and shop_id = ?");
$stmt->bind_param("ii", $customer_id, $shop_id);
$stmt->execute();
header("Location: /laundry/shop/view-customer.php");

?>

