<?php
include "../connect.php";
session_start();
$email = $_SESSION['email'];
require "include/function.php";
$state_id = $_POST['state_id'];

$stmt = $conn -> prepare("select city_state from cities where city_id = ?");
$stmt -> bind_param("i", $state_id);
$stmt -> execute();
$result = $stmt -> get_result();
while($data = $result -> fetch_assoc()){

    $states = $data['city_state'];

}


$stmt = $conn -> prepare("select DISTINCT city_name, city_id from cities where city_state = ? ORDER by city_name ASC");
$stmt -> bind_param("s",$states);
$stmt -> execute();
$result = $stmt -> get_result();
while($data = $result -> fetch_assoc()){
    echo '<option value="'.$data['city_id'].'">'. $data['city_name']
        .'</option>';
}

?>